<?php
session_start();
include('config/db.php');

if (!isset($_SESSION['user']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    echo "Invoice ID missing.";
    exit();
}

$order_id = intval($_GET['id']);
$customer = $_SESSION['user'];

// Fetch order
$order_query = "SELECT * FROM orders WHERE id = $order_id AND customer_name = '$customer'";
$order_result = mysqli_query($conn, $order_query);

if (mysqli_num_rows($order_result) === 0) {
    echo "Order not found.";
    exit();
}

$order = mysqli_fetch_assoc($order_result);

// Fetch order items
$item_query = "SELECT oi.*, inv.product_name FROM order_items oi 
               JOIN inventory inv ON oi.product_id = inv.id 
               WHERE oi.order_id = $order_id";
$item_result = mysqli_query($conn, $item_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice #<?php echo $order['id']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff7f9;
            font-family: 'Quicksand', sans-serif;
        }

        .invoice-box {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .invoice-header {
            font-size: 1.5rem;
            font-weight: bold;
            color: #ff4d6d;
            font-family:Arial, sans-serif;
        }

        .btn-secondary {
            background-color: #ffb6c1 ;
            color: white;
            border-radius: 25px;
            padding: 10px 20px;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #72aad7;
        }

        .btn-outline-primary {
            border-color: #ffb6c1 ;
            color: #ffb6c1 ;
            border-radius: 25px;
            font-weight: 600;
        }

        .btn-outline-primary:hover {
            background-color: #ff4d6d;
            color: white;
        }

        .table th, .table td {
            vertical-align: middle;
        }

        .table-light {
            background-color: #f8d7da;
        }

        .text-success {
            color: #28a745 !important;
            font-weight: bold;
        }

        hr {
            border: 1px solid #ff4d6d;
        }

        .alert {
            border-radius: 8px;
        }
    </style>
</head>
<body>

<div class="invoice-box mt-5">
    <div class="d-flex justify-content-between mb-4">
        <div class="invoice-header">Invoice #<?php echo $order['id']; ?></div>
        <div>
            <button onclick="window.print()" class="btn btn-sm btn-outline-primary">🖨️ Print</button>
        </div>
    </div>

    <p><strong>Customer:</strong> <?php echo htmlspecialchars($order['customer_name']); ?></p>
    <p><strong>Address:</strong> <?php echo htmlspecialchars($order['delivery_address']); ?></p>
    <p><strong>Payment Method:</strong> <?php echo $order['payment_method']; ?></p>
    <p><strong>Date:</strong> <?php echo date('d M Y, h:i A', strtotime($order['order_date'])); ?></p>

    <hr>

    <h5>Order Items</h5>
    <table class="table table-bordered mt-3">
        <thead class="table-light">
            <tr>
                <th>Product</th>
                <th>Qty</th>
                <th>Price (₹)</th>
                <th>Subtotal (₹)</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($item = mysqli_fetch_assoc($item_result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td><?php echo number_format($item['price'], 2); ?></td>
                    <td><?php echo number_format($item['subtotal'], 2); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="3" class="text-end">Grand Total</th>
                <th class="text-success">₹<?php echo number_format($order['total_amount'], 2); ?></th>
            </tr>
        </tfoot>
    </table>

    <div class="text-end mt-4">
        <a href="customer_invoices.php" class="btn btn-secondary">← Back to Invoices</a>
    </div>
</div>

</body>
</html>

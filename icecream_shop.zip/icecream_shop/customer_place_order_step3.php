<?php
session_start();
include('config/db.php');

// Ensure customer is logged in
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit();
}

// Check cart
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header("Location: customer_place_order_step2.php");
    exit();
}

$cart = $_SESSION['cart'];
$customer_name = $_SESSION['user'];

// Fetch product details
$ids = implode(',', array_map('intval', array_keys($cart)));
$query = "SELECT * FROM inventory WHERE id IN ($ids)";
$result = mysqli_query($conn, $query);

$products = [];
$total = 0;

while ($row = mysqli_fetch_assoc($result)) {
    $product_id = $row['id'];
    $quantity = $cart[$product_id];
    $row['quantity'] = $quantity;
    $row['subtotal'] = $row['price'] * $quantity;
    $total += $row['subtotal'];
    $products[] = $row;
}

// Handle order confirmation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    $date = date('Y-m-d H:i:s');

    // Insert order
    $insert_order = "INSERT INTO orders (customer_name, total_amount, delivery_address, order_date, status, payment_method)
                     VALUES ('$name', '$total', '$address', '$date', 'Pending', '$payment_method')";
    mysqli_query($conn, $insert_order);
    $order_id = mysqli_insert_id($conn);

    // Insert order items
    foreach ($products as $item) {
        $pid = $item['id'];
        $qty = $item['quantity'];
        $price = $item['price'];
        $subtotal = $item['subtotal'];

        $insert_item = "INSERT INTO order_items (order_id, product_id, quantity, price, subtotal)
                        VALUES ('$order_id', '$pid', '$qty', '$price', '$subtotal')";
        mysqli_query($conn, $insert_item);
    }

    // Clear cart
    unset($_SESSION['cart']);

    // Redirect
    header("Location: customer_orders.php?order=success");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Confirm Order</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff7f9;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffb6c1 !important;
        }

        .navbar-brand {
            font-family: Arial, sans-serif;
            font-size: 1.8rem;
            color: #fff !important;
        }

        .navbar .nav-link,
        .navbar span {
            color: white !important;
            font-weight: 600;
        }

        .card {
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }

        .card-header {
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
            background-color:  #ffb6c1;
            color: white;
            font-size: 1.2rem;
        }

        .list-group-item {
            border: none;
            border-bottom: 1px solid #eee;
        }

        textarea.form-control, input.form-control, select.form-select {
            border-radius: 10px;
            box-shadow: none;
        }

        .btn-success, .btn-secondary {
            border-radius: 30px;
            padding-left: 20px;
            padding-right: 20px;
            font-weight: 600;
        }

        .btn-success {
            background-color: #ffb6c1;
            border: none;
        }

        .btn-success:hover {
            background-color: #00b800;
        }

        .btn-secondary {
            background-color: #ffb6c1;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #72aad7;
        }

        h2 {
            font-weight: 600;
            color: #ff4d6d;
            font-family: Arial, sans-serif
        }

        

        .d-flex {
            justify-content: space-between;
        }

        .text-success {
            color:  #ffb6c1 !important;
        }

        .text-danger {
            color: #ffb6c1 !important;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Confirm Your Order</a>
        <div class="ms-auto text-white">
            Welcome, <?php echo $_SESSION['user']; ?> (Customer)
            <a href="logout.php" class="btn btn-outline-light ms-3">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <h2 class="text-center text-success mb-4">Your Order</h2>

    <div class="card mb-4">
        <div class="card-header">Your Items</div>
        <div class="card-body">
            <ul class="list-group">
                <?php foreach ($products as $item): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <strong><?php echo htmlspecialchars($item['product_name']); ?></strong> × <?php echo $item['quantity']; ?>
                        </div>
                        <span class="text-success fw-semibold">₹<?php echo number_format($item['subtotal'], 2); ?></span>
                    </li>
                <?php endforeach; ?>
                <li class="list-group-item d-flex justify-content-between align-items-center fw-bold bg-light">
                    Total
                    <span class="text-danger fs-5">₹<?php echo number_format($total, 2); ?></span>
                </li>
            </ul>
        </div>
    </div>

    <form method="POST">
        <div class="mb-3">
            <label for="name" class="form-label fw-semibold">Customer Name:</label>
            <input type="text" name="name" id="name" class="form-control shadow-sm"
                   value="<?php echo htmlspecialchars($customer_name); ?>" required>
        </div>

        <div class="mb-3">
            <label for="payment_method" class="form-label fw-semibold">Payment Method:</label>
            <select name="payment_method" id="payment_method" class="form-select shadow-sm" required>
                <option value="" disabled selected>Select payment method</option>
                <option value="COD">Cash on Delivery</option>
                <option value="UPI">UPI</option>
                <option value="Card">Credit/Debit Card</option>
            </select>
        </div>

        <div class="mb-4">
            <label for="address" class="form-label fw-semibold">Delivery Address:</label>
            <textarea name="address" id="address" class="form-control shadow-sm" rows="3" required></textarea>
        </div>

        <div class="d-flex justify-content-between">
            <a href="customer_place_order_step2.php" class="btn btn-secondary shadow-sm">← Back</a>
            <button type="submit" class="btn btn-success shadow-sm">Place Order →</button>
        </div>
    </form>
</div>

</body>
</html>

<?php
session_start();
include('config/db.php');

// Security check: only sales reps can access
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'sales') {
    header("Location: login.php");
    exit();
}

// Fetch inventory data
$query = "SELECT * FROM inventory ORDER BY last_updated DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory View</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #fff0f5;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffb6c1;
        }

        .navbar-brand {
            font-size: 1.8rem;
            color: #fff;
        }

        .btn-outline-light {
            color: #fff !important;
            border-color: #fff;
        }

        .btn-outline-light:hover {
            background-color:  #ffc0cb;
            color: #fff!important;
            
        }
        .btn-outline-light{
        background-color: #ffc0cb;
        }

        h3 {
            color: #cc3366;
        }

        th {
            background-color: #cc3366;
            color: white;
            font-weight: bold;
        }

        .table {
            background-color: #fff;
            border-radius: 15px;
            overflow: hidden;
        }

        .table td, .table th {
            vertical-align: middle;
        }

        .product-img {
            width: 70px;
            height: auto;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        .container {
            margin-top: 50px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg px-3">
    <div class="container-fluid">
        <span class="navbar-brand">Ice Cream Co. Sales</span>
        
    </div>
</nav>

<div class="container">
    <h3 class="mb-4">Inventory (Read Only)</h3>
    <div class="table-responsive">
        <table class="table table-bordered table-striped shadow-sm">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Image</th>
                    <th>Product</th>
                    <th>Description</th>
                    <th>Price (₹)</th>
                    <th>Available Units</th>
                    <th>Last Updated</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $counter = 1;
                while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $counter++; ?></td>
                        <td>
                            <?php if (!empty($row['image_path'])): ?>
                                <img src="uploads/<?php echo htmlspecialchars($row['image_path']); ?>" alt="Product" class="product-img"
                                     onerror="this.onerror=null; this.src='images/no-image.png';">
                            <?php else: ?>
                                <span>No image</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['description']); ?></td>
                        <td>₹<?php echo number_format($row['price'], 2); ?></td>
                        <td><?php echo $row['available_units']; ?></td>
                        <td><?php echo date('d M Y, h:i A', strtotime($row['last_updated'])); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <div class="ms-auto">
            <a href="sales_dashboard.php" class="btn btn-outline-light">← Dashboard</a>
        </div>
</div>

</body>
</html>

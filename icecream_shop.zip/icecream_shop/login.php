<?php
include('config/db.php');
session_start();

if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    $result = mysqli_query($conn, "SELECT * FROM users WHERE email='$email' AND role='$role'");

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        if (password_verify($password, $row['password'])) {
            $_SESSION['user'] = $row['name'];
            $_SESSION['role'] = $row['role'];

            if ($row['role'] == 'admin') {
                header("Location: admin_dashboard.php");
            } elseif ($row['role'] == 'sales') {
                header("Location: sales_dashboard.php");
            } else {
                header("Location: customer_dashboard.php");
            }
            exit();
        } else {
            echo "<script>alert('Incorrect password.');</script>";
        }
    } else {
        echo "<script>alert('User with selected role not found.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login - Ice Cream Co.</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #fff0f5;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffc0cb;
        }

        .navbar-brand {
            font-size: 1.8rem;
            color: #fff;
        }

        .login-box {
            background: #ffffff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 0 15px rgba(255, 182, 193, 0.4);
        }

        .form-label {
            font-weight: bold;
            color: #cc3366;
        }

        .btn-custom {
            background-color: #ff69b4;
            color: white;
            font-weight: bold;
            border: none;
        }

        .btn-custom:hover {
            background-color: #ff1493;
        }

        .footer {
            text-align: center;
            padding: 10px;
            color: #666;
            font-size: 0.9rem;
        }

        a {
            color: #cc3366;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-light">
    <div class="container">
        <a class="navbar-brand" href="index.php">🍦 Ice Cream Co.</a>
    </div>
</nav>

<div class="container mt-5">
    <div class="login-box mx-auto" style="max-width: 450px;">
        <h3 class="text-center mb-4" style="color: #cc3366;">Login to Your Account</h3>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label"> Email</label>
                <input type="email" name="email" class="form-control rounded-pill" required>
            </div>

            <div class="mb-3">
                <label class="form-label"> Password</label>
                <input type="password" name="password" class="form-control rounded-pill" required>
            </div>

            <div class="mb-3">
                <label class="form-label"> Select Role</label>
                <select name="role" class="form-select rounded-pill" required>
                    <option value="">-- Select Role --</option>
                    <option value="admin">Admin</option>
                    <option value="sales">Sales Representative</option>
                    <option value="customer">Customer</option>
                </select>
            </div>

            <button type="submit" name="submit" class="btn btn-custom w-100 rounded-pill"> Login</button>
        </form>

        <p class="text-center mt-3">Don't have an account? <a href="signup.php">Sign up here</a></p>
    </div>
</div>



</body>
</html>

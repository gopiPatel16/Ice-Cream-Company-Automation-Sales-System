<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit();
}

// Initialize cart if not set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle quantity update or item removal
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update'])) {
        foreach ($_POST['quantities'] as $product_id => $quantity) {
            if ($quantity <= 0) {
                unset($_SESSION['cart'][$product_id]);
            } else {
                $_SESSION['cart'][$product_id] = $quantity;
            }
        }
    } elseif (isset($_POST['remove'])) {
        $remove_id = $_POST['remove'];
        unset($_SESSION['cart'][$remove_id]);
    }

    header("Location: customer_place_order_step2.php");
    exit();
}

include('config/db.php');

// Fetch product details from DB based on product IDs in cart
$cart = $_SESSION['cart'];
$products = [];
$total = 0;

if (!empty($cart)) {
    $ids = implode(',', array_map('intval', array_keys($cart)));
    $query = "SELECT * FROM inventory WHERE id IN ($ids)";
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        $product_id = $row['id'];
        $quantity = $cart[$product_id];
        $row['quantity'] = $quantity;
        $row['subtotal'] = $row['price'] * $quantity;
        $total += $row['subtotal'];
        $products[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Review Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff7f9;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffb6c1 !important;
        }

        .navbar-brand {
            font-family: Arial, sans-serif;
            font-size: 1.8rem;
            color: #fff !important;
        }

        .navbar .nav-link,
        .navbar span {
            color: white !important;
            font-weight: 600;
        }

        .product-img {
            width: 70px;
            height: auto;
            border-radius: 5px;
        }

        .card {
            border-radius: 15px;
        }

        .card-body {
            background-color: #fff;
            padding: 1.25rem;
        }

        .table-dark {
            background-color: #ffb6c1;
            color: white;
        }

        .btn {
            border-radius: 2rem;
            padding: 8px 25px;
            font-weight: 600;
        }

        .btn-outline-primary {
            border-color: #ffb6c1 ;
            background-color: #ffb6c1 ;
            color: #fff;
        }

        .btn-outline-primary:hover {
            background-color: #ffcc00;
            color: white;
        }

        .btn-danger {
            background-color: #ffb6c1 ;
            border: none;
        }

        .btn-danger:hover {
            background-color: #ff1e40;
        }

        .btn-secondary {
            background-color: #ffb6c1 ;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #72aad7;
        }

        .btn-success {
            background-color: #ffb6c1 ;
            border: none;
        }

        .btn-success:hover {
            background-color: #00b800;
        }

        .text-primary {
            color: #ff4d6d;
        }

        h2 {
            color: #ff4d6d;
            font-family: Arial, sans-serif;
        }

        

        .d-flex {
            justify-content: space-between;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">Review Your Cart</a>
        <div class="ms-auto text-white">
            Welcome, <?php echo $_SESSION['user']; ?> (Customer)
            <a href="logout.php" class="btn btn-outline-light ms-3">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <h2 class="mb-4">Your Cart</h2>

    <?php if (empty($products)): ?>
        <div class="alert alert-warning">Your cart is empty.</div>
        <a href="customer_place_order_step1.php" class="btn btn-secondary">← Back to Browse</a>
    <?php else: ?>
        <form method="post">
            <table class="table table-bordered table-hover bg-white shadow-sm">
                <thead class="table-dark">
                    <tr>
                        <th>Image</th>
                        <th>Product</th>
                        <th>Price (₹)</th>
                        <th>Quantity</th>
                        <th>Subtotal (₹)</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $item): ?>
                        <tr>
                            <td><img src="uploads/<?php echo htmlspecialchars($item['image_path']); ?>" class="product-img" alt=""></td>
                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                            <td>₹<?php echo number_format($item['price'], 2); ?></td>
                            <td>
                                <input type="number" name="quantities[<?php echo $item['id']; ?>]" value="<?php echo $item['quantity']; ?>" class="form-control" min="1">
                            </td>
                            <td>₹<?php echo number_format($item['subtotal'], 2); ?></td>
                            <td>
                                <button name="remove" value="<?php echo $item['id']; ?>" class="btn btn-sm btn-danger">Remove</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="d-flex justify-content-between align-items-center mt-3">
                <h4>Total: ₹<?php echo number_format($total, 2); ?></h4>
                <div>
                    <button type="submit" name="update" class="btn btn-outline-primary me-2">Update Cart</button>
                    <a href="customer_place_order_step1.php" class="btn btn-secondary">← Back to Browse</a>
                    <a href="customer_place_order_step3.php" class="btn btn-success">Proceed to Confirm →</a>
                </div>
            </div>
        </form>
    <?php endif; ?>
</div>

</body>
</html>

<?php
session_start();
include('config/db.php');

// Security: Only admin access
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Validate product ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: admin_inventory.php");
    exit();
}

$id = intval($_GET['id']);

// Get image filename to delete
$stmt = $conn->prepare("SELECT image_path FROM inventory WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: admin_inventory.php");
    exit();
}

$product = $result->fetch_assoc();
$image_path = 'uploads/' . $product['image_path'];

// Delete product
$stmt = $conn->prepare("DELETE FROM inventory WHERE id = ?");
$stmt->bind_param("i", $id);
$delete = $stmt->execute();

// If successful, delete image and redirect
if ($delete) {
    if (file_exists($image_path)) {
        unlink($image_path);
    }
    header("Location: admin_inventory.php?deleted=true");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Delete Product - Ice Cream Co.</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff7f9;
            font-family: 'Quicksand', sans-serif;
        }

        .container {
            margin-top: 100px;
        }

        .alert {
            background-color: #ffe5ec;
            border-color: #ffa6b7;
            color: #d6336c;
            border-radius: 1rem;
            font-weight: 600;
        }

        h1 {
            font-family: 'Pacifico', cursive;
            color: #ff4d6d;
        }

        a.btn {
            border-radius: 2rem;
            font-weight: 600;
        }

        .btn-danger {
            background-color: #ff6f91;
            border: none;
        }

        .btn-danger:hover {
            background-color: #ff3366;
        }
    </style>
</head>
<body>
    <div class="container text-center">
        <h1>Oops! 🍦</h1>
        <div class="alert alert-danger mt-4">
            Failed to delete the product. Please try again later.
        </div>
        <a href="admin_inventory.php" class="btn btn-danger mt-3">Back to Inventory</a>
    </div>
</body>
</html>

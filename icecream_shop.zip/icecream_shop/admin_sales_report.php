<?php
session_start();
include('config/db.php');

// Security check
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Fetch monthly sales from orders
$monthlySales = [];
for ($i = 1; $i <= 12; $i++) {
    $month = str_pad($i, 2, '0', STR_PAD_LEFT);
    $query = mysqli_query($conn, "SELECT SUM(total_amount) AS total FROM orders WHERE MONTH(order_date) = '$month'");
    $result = mysqli_fetch_assoc($query);
    $monthlySales[] = $result['total'] ? $result['total'] : 0;
}

// Fetch yearly sales from orders
$yearlySales = [];
$currentYear = date('Y');
for ($y = $currentYear - 2; $y <= $currentYear; $y++) {
    $query = mysqli_query($conn, "SELECT SUM(total_amount) AS total FROM orders WHERE YEAR(order_date) = '$y'");
    $result = mysqli_fetch_assoc($query);
    $yearlySales[$y] = $result['total'] ? $result['total'] : 0;
}

// Fetch all orders
$sales = mysqli_query($conn, "SELECT * FROM orders ORDER BY order_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sales Report | Ice Cream Co.</title>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.sheetjs.com/xlsx-latest/package/dist/xlsx.full.min.js"></script>
    <style>
        body {
            background-color: #fff7f9;
            font-family: 'Quicksand', sans-serif;
        .navbar-brand {
            font-family: Arial, sans-serif;
            font-size: 1.8rem;
            color: #fff !important;
        }
        .navbar {
            background-color: #ffb6c1 !important;
        }

        .navbar .nav-link,
        .navbar span {
            color: white !important;
            font-weight: 600;
            background-color:: #ffccda;
        }
        }
        h3 {
            font-family: 'Pacifico', cursive;
            color: #f06292;
        }
        .table thead {
            background-color: #ffd4e3;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #fff0f6;
        }
        .btn {
            border-radius: 20px;
        }
        canvas {
            background-color: #fff;
            border-radius: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            padding: 10px;
        }
        .chart-label {
            font-weight: 600;
            color: #ff4081;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="#">Sales Report </a>
        
    </div>
</nav>


<div class="container mt-5">
   

    <div class="row mb-5">
        <div class="col-md-6">
            <h6 class="text-center chart-label">Monthly Sales (₹)</h6>
            <canvas id="monthlyChart"></canvas>
        </div>
        <div class="col-md-6">
            <h6 class="text-center chart-label">Yearly Sales (₹)</h6>
            <canvas id="yearlyChart"></canvas>
        </div>
    </div>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="text-secondary"> Order History</h5>
       
        <button class="btn btn-sm" style="background-color: #ffccda; color: white;" onclick="exportToExcel()">Export Excel</button>

    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-striped table-sm shadow-sm" id="salesTable">
            <thead>
                <tr class="text-center">
                    <th>ID</th>
                    <th>Customer</th>
                    <th>Total (₹)</th>
                    <th>Address</th>
                    <th>Status</th>
                    <th>Payment</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($sales)) { ?>
                <tr class="text-center">
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                    <td>₹<?php echo number_format($row['total_amount'], 2); ?></td>
                    <td><?php echo htmlspecialchars($row['delivery_address']); ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td><?php echo $row['payment_method']; ?></td>
                    <td><?php echo $row['order_date']; ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <div class=" mt-4">
    <a href="admin_dashboard.php" class="btn btn-sm" style="background-color: #ffccda; color: white;">← Back to Dashboard</a>

        
    </div>
</div>

<script>
    // Monthly Sales Chart
    const monthlyCtx = document.getElementById('monthlyChart').getContext('2d');
    new Chart(monthlyCtx, {
        type: 'bar',
        data: {
            labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
            datasets: [{
                label: 'Monthly Sales (₹)',
                data: <?php echo json_encode($monthlySales); ?>,
                backgroundColor: '#f48fb1',
                borderRadius: 10
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } }
        }
    });

    // Yearly Sales Chart
    const yearlyCtx = document.getElementById('yearlyChart').getContext('2d');
    new Chart(yearlyCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_keys($yearlySales)); ?>,
            datasets: [{
                label: 'Yearly Sales (₹)',
                data: <?php echo json_encode(array_values($yearlySales)); ?>,
                borderColor: '#64b5f6',
                fill: false,
                tension: 0.3,
                pointBackgroundColor: '#64b5f6',
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } }
        }
    });

    // Excel Export
    function exportToExcel() {
        let table = document.getElementById("salesTable");
        let wb = XLSX.utils.table_to_book(table, {sheet: "Sales Report"});
        XLSX.writeFile(wb, "sales_report.xlsx");
    }
</script>

</body>
</html>

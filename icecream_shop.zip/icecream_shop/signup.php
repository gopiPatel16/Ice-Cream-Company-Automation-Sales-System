<?php
include('config/db.php');

if (isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role = 'customer';

    $sql = "INSERT INTO users (name, email, password, role) VALUES ('$name', '$email', '$password', '$role')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Registration successful! Please login.'); window.location='login.php';</script>";
    } else {
        echo "<script>alert('Error: Email already exists or connection issue.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Signup - Ice Cream Co.</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #fff0f5;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffc0cb;
        }

        .navbar-brand {
            font-size: 1.8rem;
            color: #fff;
        }

        .signup-box {
            background: #fff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 0 15px rgba(255, 182, 193, 0.4);
        }

        .form-label {
            font-weight: bold;
            color: #cc3366;
        }

        .btn-custom {
            background-color: #ff69b4;
            color: white;
            font-weight: bold;
            border: none;
        }

        .btn-custom:hover {
            background-color: #ff1493;
        }

        .footer {
            text-align: center;
            padding: 10px;
            color: #666;
            font-size: 0.9rem;
        }

        a {
            color: #cc3366;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-light">
    <div class="container">
        <a class="navbar-brand" href="index.php">🍦 Ice Cream Co.</a>
    </div>
</nav>

<div class="container mt-5">
    <div class="signup-box mx-auto" style="max-width: 450px;">
        <h3 class="text-center mb-4" style="color: #cc3366;">Create a Sweet Account</h3>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label"> Name</label>
                <input type="text" name="name" class="form-control rounded-pill" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control rounded-pill" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control rounded-pill" required>
            </div>
            <button type="submit" name="submit" class="btn btn-custom w-100 rounded-pill"> Sign Up</button>
        </form>
        <p class="text-center mt-3">Already have an account? <a href="login.php">Login here</a></p>
    </div>
</div>


</body>
</html>

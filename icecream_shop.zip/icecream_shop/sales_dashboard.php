<?php
session_start();
include('config/db.php');

// Security check: only sales reps can access
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'sales') {
    header("Location: login.php");
    exit();
}

// Fetch dashboard stats from 'orders' table
$total_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM orders"))['total'];
$total_delivered = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS delivered FROM orders WHERE status = 'Delivered'"))['delivered'];
$total_pending = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS pending FROM orders WHERE status NOT IN ('Delivered', 'Cancelled')"))['pending'];
$total_sales = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_amount) AS total FROM orders"))['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sales Rep Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #fff0f5;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffc0cb;
        }

        .navbar-brand {
            font-size: 1.8rem;
            color: #fff;
        }

        .text-white, .btn-outline-light {
            color: #fff !important;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(255, 182, 193, 0.3);
            border: none;
        }

        .card-title {
            color: #cc3366;
            font-weight: bold;
        }

        h3, h4 {
            color: #cc3366;
        }

        .btn-primary {
            background-color: #ffc0cb;
            border-color: #ffc0cb;
        }

        .btn-primary:hover {
            background-color: #ff1493;
            border-color: #ff1493;
        }

        .btn-info {
            background-color: #ffc0cb;
            border-color: #ffc0cb;
            color: #fff;
        }

        .btn-warning {
            background-color: #ffc0cb;
            border-color: #ffc0cb;
            color: #fff;
        }

        .btn-secondary {
            background-color: #ffc0cb;
            border-color: #ffc0cb;
            color: #fff;
        }

        .btn-outline-secondary {
            border-color: #cc3366;
            color: #cc3366;
        }

        .btn-outline-secondary:hover {
            background-color: #cc3366;
            color: #fff;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="#"> Sales Rep Panel</a>
        <div class="ms-auto d-flex align-items-center gap-2">
            <span class="text-white">Welcome, <?php echo $_SESSION['user']; ?> (Sales)</span>
            <a href="logout.php" class="btn btn-outline-light">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h3 class="mb-4">Dashboard Overview</h3>
    <div class="row g-4">
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title"> Total Orders</h5>
                    <h2><?php echo $total_orders; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title"> Delivered</h5>
                    <h2><?php echo $total_delivered; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title"> Pending</h5>
                    <h2><?php echo $total_pending; ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title"> Total Sales</h5>
                    <h2>₹<?php echo number_format($total_sales, 2); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <hr class="my-5">

    <h4>Quick Actions</h4>
    <div class="row g-4 mt-2">
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Manage Orders</h5>
                    <p class="card-text">Update status of orders placed by customers.</p>
                    <a href="sales_manage_orders.php" class="btn btn-primary">Go to Orders</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Customer Info</h5>
                    <p class="card-text">View customer details and order history.</p>
                    <a href="sales_customer_info.php" class="btn btn-info">View Customers</a>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mt-3">
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Invoice Generator</h5>
                    <p class="card-text">Generate and send invoices for customer orders.</p>
                    <a href="sales_invoice.php" class="btn btn-warning">Generate Invoice</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Inventory (View Only)</h5>
                    <p class="card-text">Check available stock. (Read-only access)</p>
                    <a href="sales_inventory_view.php" class="btn btn-secondary">View Inventory</a>
                </div>
            </div>
        </div>
    </div>

    <div class="mt-4">
        <a href="index.php" class="btn btn-outline-secondary">← Back</a>
    </div>
</div>

</body>
</html>

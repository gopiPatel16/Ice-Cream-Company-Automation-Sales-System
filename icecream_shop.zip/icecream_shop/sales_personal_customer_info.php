<?php
session_start();
include('config/db.php');

if (!isset($_SESSION['user']) || $_SESSION['role'] != 'sales') {
    header("Location: login.php");
    exit();
}

$customer_name = mysqli_real_escape_string($conn, $_GET['name'] ?? '');

$orders = mysqli_query($conn, "SELECT * FROM orders WHERE customer_name = '$customer_name' ORDER BY order_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo htmlspecialchars($customer_name); ?> - Orders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #fff0f5;
            font-family: Arial, sans-serif;
        }

        h3 {
            color: #d63384;
            font-weight: bold;
        }

        .btn-secondary {
            background-color: #ffc0cb;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #ff8fb2;
        }

        .card {
            border-radius: 16px;
            box-shadow: 0 0 10px rgba(255, 182, 193, 0.4);
        }

        .card-body {
            background-color: #fff;
        }

        .table thead {
            background-color: #ffe4e1;
        }

        .table th, .table td {
            vertical-align: middle;
        }

        .alert-info {
            background-color: #fde2e4;
            color: #c91c57;
            font-weight: 500;
            border: none;
        }
    </style>
</head>
<body>

<div class="container mt-4">
    <h3> Orders of <?php echo htmlspecialchars($customer_name); ?></h3>
    <a href="sales_customer_info.php" class="btn btn-secondary mb-3">← Back to Customers</a>

    <div class="card">
        <div class="card-body">
            <?php if (mysqli_num_rows($orders) > 0): ?>
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>#Order ID</th>
                            <th>Date</th>
                            <th>Amount (₹)</th>
                            <th>Status</th>
                            <th>Payment</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($orders)) { ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo date("d M Y, h:i A", strtotime($row['order_date'])); ?></td>
                                <td><?php echo number_format($row['total_amount'], 2); ?></td>
                                <td><?php echo $row['status']; ?></td>
                                <td><?php echo $row['payment_method']; ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-info">No orders found for this customer.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>

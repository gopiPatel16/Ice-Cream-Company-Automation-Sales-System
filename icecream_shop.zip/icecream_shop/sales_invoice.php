<?php
session_start();
include('config/db.php'); // Make sure db.php is in 'config/' folder inside 'mobile_shop'

// Check if user is logged in and is a sales/admin role
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'sales') {
    header("Location: login.php");
    exit();
}

// Fetch all completed customer orders
$query = "SELECT * FROM orders WHERE status = 'Delivered' ORDER BY order_date DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Generate Customer Invoices</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #fff0f5;
            font-family: Arial, sans-serif;
        }
       

        .container {
            margin-top: 60px;
            background: #fff;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 0 15px rgba(255, 182, 193, 0.4);
        }
        .container2 {
            margin-top: 1px;
            
            padding: 30px;
        
            
        }

        h3 {
            color: #cc3366;
        }

        .table th {
            background-color: #ffb6c1;
            color: #fff;
        }

        .table td, .table th {
            vertical-align: middle;
        }

        .btn-warning {
            background-color: #ffb6c1;
            border: none;
            color: #fff;
        }

        .btn-warning:hover {
            background-color: #faae2b;
        }

        .btn-secondary {
            background-color: #ffb6c1;
           
            border: none;
        }

        .btn-secondary:hover {
            background-color: #ff8fb2;
        }

        .alert-info {
            background-color: #fce4ec;
            color: #cc3366;
            border: 1px solid #f8bbd0;
        }
    </style>
</head>
<body>

    <div class="container">
        <h3 class="mb-4"> Generate Customer Invoices</h3>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped shadow-sm">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Payment</th>
                            <th>Invoice</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($order = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td>#<?php echo $order['id']; ?></td>
                                <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                                <td><?php echo date("d M Y, h:i A", strtotime($order['order_date'])); ?></td>
                                <td>₹<?php echo number_format($order['total_amount'], 2); ?></td>
                                <td><?php echo $order['payment_method']; ?></td>
                                <td>
                                    <a href="sales_print_invoice.php?id=<?php echo $order['id']; ?>" class="btn btn-warning btn-sm">
                                        View Invoice
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">No completed orders available to generate invoices.</div>
        <?php endif; ?>

       
    </div>
    <div class="container2">
    <a href="sales_dashboard.php" class="btn btn-secondary mt-3">← Back to Dashboard</a>
        </div>
</body>
</html>

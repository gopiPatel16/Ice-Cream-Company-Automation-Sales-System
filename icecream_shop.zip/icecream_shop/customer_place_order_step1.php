<?php
session_start();
include('config/db.php');

// Security check
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit();
}

// Initialize cart if not set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle Add to Cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];
    
    // If already in cart, increment quantity
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]++;
    } else {
        $_SESSION['cart'][$product_id] = 1;
    }

    header("Location: customer_place_order_step1.php"); // Stay on the page
    exit();
}

// Fetch available products
$query = "SELECT * FROM inventory ORDER BY product_name ASC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Browse Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff7f9;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffb6c1 !important;
        }

        .navbar-brand {
            font-family: Arial, sans-serif;
            font-size: 1.8rem;
            color: #fff !important;
        }

        .navbar .nav-link,
        .navbar span {
            color: white !important;
            font-weight: 600;
        }

        .product-img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-top-left-radius: 0.375rem;
            border-top-right-radius: 0.375rem;
        }

        .card {
            border-radius: 15px;
        }

        .card-body {
            background-color: #fff;
            padding: 1.25rem;
        }

        .card-title {
            font-weight: 600;
            color: #ff4d6d;
        }

        .card-text {
            font-size: 0.9rem;
            color: #6c757d;
        }

        .btn {
    border-radius: 4px; /* or 0 if you want completely square */
    padding: 8px 25px;
    font-weight: 600;
}

.btn-square {
    border-radius: 4px !important; /* or 0 */
}


        .btn-primary {
            background-color: #ffb6c1;

            border: none;
        }

        .btn-primary:hover {
            background-color: #ff9900;
        }

        .btn-secondary {
            background-color:#ffb6c1;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #72aad7;
        }

        .btn-success {
            background-color: #ffb6c1;
            border: none;
        }

        .btn-success:hover {
            background-color: #00b800;
        }

        h2 {
            color: #ff4d6d;
            font-family:Arial, sans-serif;
        }

        

        .text-primary {
            color: #ff4d6d;
        }

        .alert {
            font-weight: bold;
            text-align: center;
        }

        .d-flex {
            justify-content: space-between;
        }

    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">Browse Ice Creams</a>
        <div class="ms-auto text-white">
            Welcome, <?php echo $_SESSION['user']; ?> (Customer)
            <a href="logout.php" class="btn btn-outline-light ms-3">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <h2 class="mb-4">Ice Creams</h2>

    <div class="row">
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm h-100">
                    <img src="uploads/<?php echo htmlspecialchars($row['image_path']); ?>" class="card-img-top product-img" alt="Image">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($row['product_name']); ?></h5>
                        <p class="card-text text-muted"><?php echo htmlspecialchars($row['description']); ?></p>
                        <p><strong>₹<?php echo number_format($row['price'], 2); ?></strong></p>
                        <form method="POST">
                            <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                            <button type="submit" class="btn btn-sm btn-primary btn-square">Add to Cart</button>

                        </form>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>

    <div class="d-flex justify-content-between mt-4">
        <a href="customer_dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
        <a href="customer_place_order_step2.php" class="btn btn-success">Review Cart →</a>
    </div>
</div>

</body>
</html>

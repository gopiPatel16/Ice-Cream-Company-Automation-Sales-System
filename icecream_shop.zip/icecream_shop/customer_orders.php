<?php
session_start();
include('config/db.php');

// Redirect if not logged in as customer
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit();
}

$customer_name = $_SESSION['user'];

// Handle delete (cancel) order
if (isset($_GET['delete_order'])) {
    $order_id = intval($_GET['delete_order']);

    // Delete order items first (foreign key constraint)
    mysqli_query($conn, "DELETE FROM order_items WHERE order_id = $order_id");

    // Then delete the order
    mysqli_query($conn, "DELETE FROM orders WHERE id = $order_id AND customer_name = '$customer_name'");

    // Redirect to avoid resubmission
    header("Location: customer_orders.php?deleted=1");
    exit();
}

// Fetch customer orders
$order_query = "SELECT * FROM orders WHERE customer_name = '$customer_name' ORDER BY order_date DESC";
$order_result = mysqli_query($conn, $order_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Orders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff7f9;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffb6c1 !important;
        }

        .navbar-brand {
            font-family: Arial, sans-serif;
            font-size: 1.8rem;
            color: #fff !important;
        }

        .navbar .nav-link,
        .navbar span {
            color: white !important;
            font-weight: 600;
        }

        .card {
            border-radius: 15px;
        }

        .card-header {
            background-color: #ffa6b7;
            color: white;
            font-weight: 600;
        }

        .order-box {
            transition: all 0.3s ease;
        }

        .order-box:hover {
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .btn {
            border-radius: 2rem;
            padding: 8px 25px;
            font-weight: 600;
        }

        .btn-danger {
            background-color: #ff4d6d;
            border: none;
        }

        .btn-danger:hover {
            background-color: #ff1f3c;
        }

        .btn-primary {
            background-color: #ffcc00;
            border: none;
        }

        .btn-primary:hover {
            background-color: #ff9900;
        }

        .btn-secondary {
            background-color:  #ffb6c1;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #72aad7;
        }

        h2 {
            color: #ff4d6d;
            font-family: Arial, sans-serif;
        }

        .alert {
            font-weight: bold;
            text-align: center;
        }

        

        .text-primary {
            color: #ff4d6d;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="#">Order History</a>
        <div class="ms-auto text-white">
            Welcome, <?php echo $_SESSION['user']; ?> (Customer)
            <a href="logout.php" class="btn btn-outline-light ms-3">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <h2 class="mb-4">My Orders</h2>

    <?php if (isset($_GET['order']) && $_GET['order'] === 'success'): ?>
        <div class="alert alert-success">Your order has been placed successfully!</div>
    <?php endif; ?>

    <?php if (isset($_GET['deleted']) && $_GET['deleted'] == 1): ?>
        <div class="alert alert-danger">Order has been canceled.</div>
    <?php endif; ?>

    <?php if (mysqli_num_rows($order_result) == 0): ?>
        <div class="alert alert-warning">You have no orders yet.</div>
        <a href="customer_place_order_step1.php" class="btn btn-primary">Place First Order</a>
    <?php else: ?>
        <?php while ($order = mysqli_fetch_assoc($order_result)): ?>
            <?php
                $order_id = $order['id'];
                $item_query = "SELECT oi.*, i.product_name FROM order_items oi 
                               JOIN inventory i ON oi.product_id = i.id 
                               WHERE oi.order_id = '$order_id'";
                $items_result = mysqli_query($conn, $item_query);
            ?>
            <div class="card mb-4 order-box shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        Order #<?php echo $order_id; ?> • <?php echo date('d M Y, h:i A', strtotime($order['order_date'])); ?>
                    </div>
                    <a href="customer_orders.php?delete_order=<?php echo $order_id; ?>" 
                       class="btn btn-sm btn-danger" 
                       onclick="return confirm('Are you sure you want to cancel this order?');">
                        Cancel Order
                    </a>
                </div>
                <div class="card-body">
                    <p><strong>Status:</strong> <?php echo $order['status']; ?></p>
                    <p><strong>Delivery Address:</strong> <?php echo htmlspecialchars($order['delivery_address']); ?></p>
                    
                    <h6 class="mt-4">Items:</h6>
                    <ul class="list-group mb-3">
                        <?php while ($item = mysqli_fetch_assoc($items_result)): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo htmlspecialchars($item['product_name']); ?> x <?php echo $item['quantity']; ?>
                                <span>₹<?php echo number_format($item['subtotal'], 2); ?></span>
                            </li>
                        <?php endwhile; ?>
                    </ul>

                    <div class="text-end">
                        <strong>Total: ₹<?php echo number_format($order['total_amount'], 2); ?></strong>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    <?php endif; ?>

    <div class="text-start mt-4">
        <a href="customer_dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
    </div>
</div>

</body>
</html>

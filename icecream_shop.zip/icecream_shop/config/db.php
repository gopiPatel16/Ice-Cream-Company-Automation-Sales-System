<?php
$host = "localhost";
$user = "root"; // Update as per your local server
$password = "Lalit@5015"; // Update as per your local server
$db = "icecream_db";

$conn = mysqli_connect($host, $user, $password, $db);

if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());
}
?>

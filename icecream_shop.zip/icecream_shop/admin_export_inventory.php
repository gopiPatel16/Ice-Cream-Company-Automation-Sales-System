<?php
include('config/db.php');

// Set headers to export as Excel file
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=icecream_inventory_" . date("Y-m-d") . ".xls");
header("Pragma: no-cache");
header("Expires: 0");

// Fetch inventory data
$query = "SELECT id, product_name, available_units, price, last_updated FROM inventory";
$result = mysqli_query($conn, $query);

// Output as Excel Table
echo "<table border='1'>";
echo "<tr style='background-color:#ffd6e0; font-weight:bold;'>
        <th>ID</th>
        <th>Product Name</th>
        <th>Available Units</th>
        <th>Price (₹)</th>
        <th>Last Updated</th>
      </tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>
            <td>{$row['id']}</td>
            <td>" . htmlspecialchars($row['product_name']) . "</td>
            <td>{$row['available_units']}</td>
            <td>{$row['price']}</td>
            <td>{$row['last_updated']}</td>
          </tr>";
}
echo "</table>";
?>

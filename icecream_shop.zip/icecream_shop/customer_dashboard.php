<?php
session_start();
include('config/db.php');

// Check if user is logged in and is a customer
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard - Ice Cream Co.</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff7f9;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffb6c1 !important;
        }

        .navbar-brand {
            font-family: Arial, sans-serif;
            font-size: 1.8rem;
            color: #fff !important;
        }

        .navbar .nav-link,
        .navbar span {
            color: white !important;
            font-weight: 600;
        }

        h3 {
            font-weight: bold;
            color: #ff4d6d;
            font-family: Arial, sans-serif;
        }

        .card {
            border-radius: 1.5rem;
            transition: 0.3s ease-in-out;
            border: none;
            background-color: #fff;
        }

        .card:hover {
            transform: scale(1.02);
            box-shadow: 0 6px 24px rgba(0, 0, 0, 0.1);
        }

        .card-title {
            font-weight: 600;
            color: #ff6f91;
        }

        .btn {
            border-radius: 2rem;
            padding: 6px 20px;
            font-weight: 600;
        }

        .btn-primary {
            background-color: #ffb6c1 ;
            border: none;
        }

        .btn-success {
            background-color: #ffb6c1 ;
            border: none;
        }

        .btn-warning {
            background-color: #ffb6c1 ;
            border: none;
        }

        .btn-info {
            background-color: #ffb6c1 ;
            border: none;
            
        }

        .btn-secondary {
            background-color: #ffb6c1 ;
            border: none;
            
        }

        .btn-outline-light {
            border-color: white;
        }

    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="#">Customer Dashboard</a>
        <div class="ms-auto d-flex align-items-center gap-3 text-white">
            <span>Welcome, <?php echo $_SESSION['user']; ?> (Customer)</span>
            <a href="logout.php" class="btn btn-outline-light">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <h3 class="mb-4"></h3>
    <div class="row g-4">

        <div class="col-md-6">
            <div class="card shadow h-100">
                <div class="card-body">
                    <h5 class="card-title">My Orders</h5>
                    <p class="card-text">View past & current orders, check status, and cancel if pending.</p>
                    <a href="customer_orders.php" class="btn btn-primary">View Orders</a>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow h-100">
                <div class="card-body">
                    <h5 class="card-title">Place New Order</h5>
                    <p class="card-text">Browse available ice creams and place a new order.</p>
                    <a href="customer_place_order_step1.php" class="btn btn-success">Start Order</a>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow h-100">
                <div class="card-body">
                    <h5 class="card-title">Invoices</h5>
                    <p class="card-text">Download or view your past invoices.</p>
                    <a href="customer_invoices.php" class="btn btn-warning" style="color: white;">View Invoices</a>

                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow h-100">
                <div class="card-body">
                    <h5 class="card-title">Contact / Support</h5>
                    <p class="card-text">Raise an issue or ask for help regarding your order.</p>
                    <a href="customer_support.php" class="btn btn-info" style="color: white;">Get Help</a>

                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card shadow h-100">
                <div class="card-body">
                    <h5 class="card-title">Account Settings</h5>
                    <p class="card-text">Update your profile information or change your password.</p>
                    <a href="customer_account_settings.php" class="btn btn-secondary">Manage Account</a>
                </div>
            </div>
        </div>

    </div>
</div>

</body>
</html>

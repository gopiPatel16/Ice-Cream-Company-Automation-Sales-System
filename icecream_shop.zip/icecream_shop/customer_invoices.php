<?php
session_start();
include('config/db.php');

if (!isset($_SESSION['user']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit();
}

$customer = $_SESSION['user'];

$query = "SELECT * FROM orders WHERE customer_name = '$customer' AND status = 'Delivered' ORDER BY order_date DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Invoices</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff7f9;
            font-family: 'Quicksand', sans-serif;
        }

        .navbar {
            background-color: #ffb6c1 !important;
        }

        .navbar-brand {
            font-family: Arial, sans-serif;
            font-size: 1.8rem;
            color: #fff !important;
        }

        .navbar .nav-link,
        .navbar span {
            color: white !important;
            font-weight: 600;
        }

        .container {
            margin-top: 10px;
            
        }

        h3 {
            color: #ff4d6d;
            font-family: Arial, sans-serif;
            text-align: center;
            padding-bottom:20px;
            padding-top:30px;
        }

        .table th, .table td {
            vertical-align: middle;
        }

        .btn-secondary {
            background-color: #ffb6c1;
            color: white;
            border-radius: 25px;
            padding: 10px 20px;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #72aad7;
        }

        .btn-warning {
            background-color: #ffb6c1;
            color: white;
            border-radius: 25px;
        }

        .btn-warning:hover {
            background-color: #ffb6c1;
        }

        .alert {
            border-radius: 8px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Invoices</a>
        <div class="ms-auto text-white">
            Welcome, <?php echo $_SESSION['user']; ?> (Customer)
            <a href="logout.php" class="btn btn-outline-light ms-3">Logout</a>
        </div>
    </div>
</nav>

<div class="container">
    <h3>Your Completed Orders / Invoices</h3>

    <?php if (mysqli_num_rows($result) > 0): ?>
        <table class="table table-bordered bg-white shadow-sm">
            <thead class="table-secondary">
                <tr>
                    <th>Order ID</th>
                    <th>Date</th>
                    <th>Total</th>
                    <th>Payment</th>
                    <th>Invoice</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($order = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td>#<?php echo $order['id']; ?></td>
                        <td><?php echo date("d M Y, h:i A", strtotime($order['order_date'])); ?></td>
                        <td>₹<?php echo number_format($order['total_amount'], 2); ?></td>
                        <td><?php echo $order['payment_method']; ?></td>
                        <td>
                            <a href="customer_print_invoice.php?id=<?php echo $order['id']; ?>" class="btn btn-warning btn-sm">
                                View Invoice
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="alert alert-info">No completed orders found.</div>
    <?php endif; ?>

    <!-- 🔙 Back to Dashboard Button -->
    <div class="mt-4 text-start">
        <a href="customer_dashboard.php" class="btn btn-secondary">
        ← Back to Dashboard
        </a>
    </div>

</div>

</body>
</html>

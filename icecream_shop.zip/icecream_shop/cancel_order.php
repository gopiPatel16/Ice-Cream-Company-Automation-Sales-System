<?php
session_start();
include('config/db.php');

// Security check
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'])) {
    $order_id = intval($_POST['order_id']);
    $customer = $_SESSION['user'];

    // Update status only if it's pending and belongs to this user
    $check_query = "SELECT * FROM orders WHERE id = $order_id AND customer_name = '$customer' AND status = 'Pending'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        $update_query = "UPDATE orders SET status = 'Cancelled' WHERE id = $order_id";
        mysqli_query($conn, $update_query);
    }
}

header("Location: customer_orders.php");
exit();

<?php
session_start();
include('config/db.php');

// Security check: only admin can access
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Add User
if (isset($_POST['add_user'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role = $_POST['role'];

    $checkEmail = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if (mysqli_num_rows($checkEmail) > 0) {
        echo "<script>alert('Email already exists!');</script>";
    } else {
        $insert = "INSERT INTO users (name, email, password, role) VALUES ('$name', '$email', '$password', '$role')";
        if (mysqli_query($conn, $insert)) {
            echo "<script>alert('User added successfully!'); window.location='admin_dashboard.php';</script>";
        } else {
            echo "<script>alert('Error adding user.');</script>";
        }
    }
}

// Delete User
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM users WHERE id='$id'");
    echo "<script>alert('User deleted successfully!'); window.location='admin_dashboard.php';</script>";
}

// Edit User - Fetch details
$edit_user = null;
if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $edit_result = mysqli_query($conn, "SELECT * FROM users WHERE id='$edit_id'");
    if (mysqli_num_rows($edit_result) > 0) {
        $edit_user = mysqli_fetch_assoc($edit_result);
    }
}

// Update User
if (isset($_POST['update_user'])) {
    $update_id = $_POST['update_id'];
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $role = $_POST['role'];

    mysqli_query($conn, "UPDATE users SET name='$name', email='$email', role='$role' WHERE id='$update_id'");
    echo "<script>alert('User updated successfully!'); window.location='admin_dashboard.php';</script>";
}

// Fetch all users
$users = mysqli_query($conn, "SELECT * FROM users");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard - Ice Cream Co.</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff7f9;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffb6c1 !important;
        }

        .navbar-brand {
            font-family: Arial, sans-serif;
            font-size: 1.8rem;
            color: #fff !important;
        }

        .navbar .nav-link,
        .navbar span {
            color: white !important;
            font-weight: 600;
        }

        .card {
            border: none;
            border-radius: 1.5rem;
            background-color: #fff;
        }

        .card-header {
            border-top-left-radius: 1.5rem;
            border-top-right-radius: 1.5rem;
            font-weight: 600;
            font-size: 1.1rem;
            background-color: #ffa6b7;
            color: #fff;
        }

        .btn {
            border-radius: 2rem;
            padding: 6px 20px;
            font-weight: 600;
        }

        .btn-danger {
            background-color: #ffb6c1 ;
            border: none;
        }

        .btn-danger:hover {
            background-color: #ff3366;
        }

        .btn-outline-light {
            border-color: white;
        }

        h3 {
            font-weight: bold;
            color: #ff4d6d;
            font-family: Arial, sans-serif;
        }

        table th {
            background-color: #ffc1cc !important;
            color: #333;
            font-weight: 600;
        }

        hr {
            border-top: 2px dashed #ffa6b7;
        }

        .card-title {
            font-weight: 600;
            color: #ff6f91;
        }

        .btn-success {
            background-color: #ffb6c1 ;
            border: none;
        }

        .btn-warning {
            background-color: #ffb6c1 ;
            color:#fff;
            border: none;
        }

        .btn-primary {
            background-color: #ffb6c1 ;
            border: none;
        }

        .table td, .table th {
            vertical-align: middle;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="#">Admin Dashboard</a>
        <div class="ms-auto d-flex align-items-center gap-3">
            <span>Welcome, <?php echo $_SESSION['user']; ?> (Admin)</span>
            <a href="logout.php" class="btn btn-outline-light">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-5">

    <h3 class="mb-4">Manage Users</h3>

    <!-- Add / Edit User Form -->
    <div class="card mb-4 shadow">
        <div class="card-header">
            <?php echo $edit_user ? "Edit User (ID: {$edit_user['id']})" : "Add New User"; ?>
        </div>
        <div class="card-body">
            <form method="POST">
                <?php if ($edit_user) { ?>
                    <input type="hidden" name="update_id" value="<?php echo $edit_user['id']; ?>">
                <?php } ?>
                <div class="row g-3">
                    <div class="col-md-3">
                        <input type="text" name="name" class="form-control" placeholder="Full Name" required
                               value="<?php echo $edit_user ? $edit_user['name'] : ''; ?>">
                    </div>
                    <div class="col-md-3">
                        <input type="email" name="email" class="form-control" placeholder="Email" required
                               value="<?php echo $edit_user ? $edit_user['email'] : ''; ?>">
                    </div>
                    <?php if (!$edit_user) { ?>
                        <div class="col-md-3">
                            <input type="password" name="password" class="form-control" placeholder="Password" required>
                        </div>
                    <?php } ?>
                    <div class="col-md-2">
                        <select name="role" class="form-select" required>
                            <option value="">Select Role</option>
                            <option value="admin" <?php if ($edit_user && $edit_user['role'] == 'admin') echo 'selected'; ?>>Admin</option>
                            <option value="sales" <?php if ($edit_user && $edit_user['role'] == 'sales') echo 'selected'; ?>>Sales Representative</option>
                            <option value="customer" <?php if ($edit_user && $edit_user['role'] == 'customer') echo 'selected'; ?>>Customer</option>
                        </select>
                    </div>
                    <div class="col-md-1 d-grid">
                        <?php if ($edit_user) { ?>
                            <button type="submit" name="update_user" class="btn btn-danger">Update</button>
                        <?php } else { ?>
                            <button type="submit" name="add_user" class="btn btn-danger">Add</button>
                        <?php } ?>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Users Table -->
    <table class="table table-bordered table-hover shadow-sm">
        <thead class="table-danger">
            <tr>
                <th>#ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($users)) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo ucfirst($row['role']); ?></td>
                    <td><?php echo $row['created_at']; ?></td>
                    <td>
                        <a href="admin_dashboard.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                        <a href="admin_dashboard.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <!-- Cards: Inventory + Sales Reports -->
    <hr class="my-5">

    <h3 class="mb-4">Quick Access</h3>
    <div class="row g-4">
        <div class="col-md-6">
            <div class="card shadow rounded-4 h-100">
                <div class="card-body">
                    <h5 class="card-title">Inventory</h5>
                    <p class="card-text">View and manage your current product stock levels.</p>
                    <a href="admin_inventory.php" class="btn btn-success">Go to Inventory</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow rounded-4 h-100">
                <div class="card-body">
                    <h5 class="card-title">Sales Reports</h5>
                    <p class="card-text">Analyze sales performance and export reports.</p>
                    <a href="admin_sales_report.php" class="btn btn-warning">View Sales Reports</a>
                </div>
            </div>
        </div>
    </div>

</div>
</body>
</html>

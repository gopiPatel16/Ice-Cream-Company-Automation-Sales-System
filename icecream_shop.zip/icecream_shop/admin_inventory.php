<?php 
session_start();
include('config/db.php');

// Security check: only admin can access
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Fetch inventory
$query = "SELECT * FROM inventory ORDER BY last_updated DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Inventory | Ice Cream Co.</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff7f9;
            font-family: Arial, sans-serif;
            .navbar {
            background-color: #ffb6c1 !important;
        }
       
        .navbar-brand {
            font-family: Arial, sans-serif;
            font-size: 1.8rem;
            color: #fff !important;
        }

        .navbar .nav-link,
        .navbar span {
            color: white !important;
            font-weight: 600;
        }
        .btn-custom {
    background-color: #ffb6c1 !important;
    color: white !important;
    border: none !important;
}
.btn-custom:hover {
    background-color: #ff9ab2 !important;
    color: white !important;
}


        }
        h2 {
            font-family: Arial, sans-serif;
            color: #f06292;
        }
        
        .btn {
            border-radius: 20px;
        }
        .product-img {
            width: 80px;
            height: auto;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .table thead {
            background-color: #ffccda;
        }
        .table td, .table th {
            vertical-align: middle;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #fff1f7;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="#">Inventory Management</a>
        
    </div>
</nav>

<div class="container">
    <h2 class="mb-4 text-center"></h2>

    <div class="d-flex justify-content-between align-items-center mb-4">
    <a href="admin_add_product.php" class="btn btn-custom px-4">Add Product</a>

       
    </div>

    <div class="table-responsive">
        <table class="table table-striped table-bordered shadow-sm rounded-4 overflow-hidden">
            <thead>
                <tr class="text-center">
                    <th>ID</th>
                    <th>Image</th>
                    <th>Product Name</th>
                    <th>Available Units</th>
                    <th>Price (₹)</th>
                    <th>Last Updated</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr class="text-center">
                    <td><?php echo $row['id']; ?></td>
                    <td>
                        <?php if (!empty($row['image_path'])): ?>
                            <img src="uploads/<?php echo htmlspecialchars($row['image_path']); ?>" class="product-img" alt="Product">
                        <?php else: ?>
                            <span class="text-muted">No image</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                    <td><?php echo $row['available_units']; ?></td>
                    <td>₹<?php echo number_format($row['price'], 2); ?></td>
                    <td><?php echo $row['last_updated']; ?></td>
                    <td>
                    <a href="admin_edit_product.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-custom">Edit</a>
<a href="admin_delete_product.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-custom" onclick="return confirm('Delete this product?');">Delete</a>
</td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-between align-items-center mb-4">
    <a href="admin_dashboard.php" class="btn btn-custom px-4">← Back to Dashboard</a>

        <form action="admin_export_inventory.php" method="post">
        <button type="submit" class="btn btn-custom px-4">Export to Excel</button>

        </form>
       
    </div>
</div>

</body>
</html>

<?php
session_start();
include('config/db.php');

// Security check
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'customer') {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['user'];

// Get customer ID from users table
$getIdQuery = "SELECT id FROM users WHERE name = '$username' LIMIT 1";
$getIdResult = mysqli_query($conn, $getIdQuery);
$customerData = mysqli_fetch_assoc($getIdResult);
$customer_id = $customerData['id'] ?? null;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    if ($customer_id) {
        $query = "INSERT INTO support_requests (customer_id, name, email, message, submitted_at) 
                  VALUES ('$customer_id', '$name', '$email', '$message', NOW())";

        if (mysqli_query($conn, $query)) {
            $success = "✅ Your request has been submitted. We’ll get back to you shortly.";
        } else {
            $error = "❌ Something went wrong. Please try again later.";
        }
    } else {
        $error = "❌ Customer ID not found. Please try again later.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Support | Mobile Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff7f9;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffb6c1 !important;
        }

        .navbar-brand {
            font-family: Arial, sans-serif;
            font-size: 1.8rem;
            color: #fff !important;
        }

        .navbar .nav-link,
        .navbar span {
            color: white !important;
            font-weight: 600;
        }

        .support-card {
            max-width: 650px;
            margin: 40px auto;
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 0 15px rgba(0,0,0,0.05);
        }

        .support-card h2 {
            text-align: center;
            color: #ff4d6d;
            margin-bottom: 20px;
            font-family: Arial, sans-serif;
        }

        .form-label {
            font-weight: 500;
        }

        .btn-primary {
            padding: 10px 20px;
            font-weight: 500;
            border-radius: 25px;
            background-color: #ffb6c1;
            border: none;
        }

        .btn-primary:hover {
            background-color: #ff2d53;
        }

        .btn-secondary {
            border-radius: 25px;
            background-color:#ffb6c1;
            padding: 10px 20px;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #72aad7;
        }

        .alert {
            border-radius: 8px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Contact Support</a>
        <div class="ms-auto text-white">
            Welcome, <?php echo $_SESSION['user']; ?> (Customer)
            <a href="logout.php" class="btn btn-outline-light ms-3">Logout</a>
        </div>
    </div>
</nav>

<div class="container">
    <div class="support-card">
        <h2>Contact Support</h2>

        <?php if (isset($success)) { ?>
            <div class="alert alert-success text-center"><?php echo $success; ?></div>
        <?php } elseif (isset($error)) { ?>
            <div class="alert alert-danger text-center"><?php echo $error; ?></div>
        <?php } ?>

        <form method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">Your Name</label>
                <input type="text" name="name" id="name" class="form-control" required 
                       value="<?php echo htmlspecialchars($_SESSION['user']); ?>">
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Your Email</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="message" class="form-label">Your Message</label>
                <textarea name="message" id="message" rows="4" class="form-control" required></textarea>
            </div>

            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary">Submit Request</button>
                <a href="customer_dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
            </div>
        </form>
    </div>
</div>

</body>
</html>

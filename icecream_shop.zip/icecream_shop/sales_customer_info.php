<?php
session_start();
include('config/db.php');

// Security check: only sales role
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'sales') {
    header("Location: login.php");
    exit();
}

// Fetch customer summary from orders table
$customers = mysqli_query($conn, "
    SELECT 
        customer_name,
        delivery_address,
        COUNT(*) AS total_orders,
        SUM(total_amount) AS total_spent
    FROM orders
    GROUP BY customer_name, delivery_address
    ORDER BY total_spent DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Customer Info</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #fff0f5;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffb6c1;
        }

        .navbar-brand {
            font-size: 1.8rem;
            color: #fff;
        }

        .text-white, .btn-outline-light {
            color: #fff !important;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(255, 182, 193, 0.3);
            border: none;
        }

        .card-header {
            background-color: #ffb6c1;
            color: #fff !important;
            font-weight: bold;
        }

        .table > thead {
            background-color: #ffe4e1;
        }

        .btn-info {
            background-color: #ffb6c1;
            border-color: #ffb6c1;
            color: #fff;
        }

        .btn-info:hover {
            background-color: #00bfff;
            border-color: #00bfff;
        }

        .btn-secondary {
            background-color: #ffc0cb;
            border-color: #ffc0cb;
            color: #fff;
        }

        .btn-secondary:hover {
            background-color: #ffc0cb;
            border-color: #ffc0cb;
        }

        h3 {
            color: #cc3366;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="#">Customer Info & Orders</a>
        <div class="ms-auto d-flex align-items-center gap-2">
            <span class="text-white">Welcome, <?php echo $_SESSION['user']; ?> (Sales)</span>
            <a href="logout.php" class="btn btn-outline-light">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
 

   

    <div class="card shadow">
        <div class="card-header">Customer Summary</div>
        <div class="card-body">
            <table class="table table-bordered table-hover rounded">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Customer Name</th>
                        <th>Address</th>
                        <th>Total Orders</th>
                        <th>Total Spent (₹)</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $count = 1;
                    while ($row = mysqli_fetch_assoc($customers)) { ?>
                        <tr>
                            <td><?php echo $count++; ?></td>
                            <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['delivery_address']); ?></td>
                            <td><?php echo $row['total_orders']; ?></td>
                            <td><?php echo number_format($row['total_spent'], 2); ?></td>
                            <td>
                                <a href="sales_personal_customer_info.php?name=<?php echo urlencode($row['customer_name']); ?>" class="btn btn-sm btn-info">View Orders</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <br>
    <a href="sales_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>
</div>

</body>
</html>

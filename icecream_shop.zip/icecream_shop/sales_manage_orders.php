<?php
session_start();
include('config/db.php');

// Security check
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'sales') {
    header("Location: login.php");
    exit();
}

// Update Order Status
if (isset($_POST['update_order'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];

    $update = "UPDATE orders SET status='$status' WHERE id=$order_id";
    mysqli_query($conn, $update);
    echo "<script>alert('Order status updated!'); window.location='sales_manage_orders.php';</script>";
}

// Fetch orders placed by customers
$orders = mysqli_query($conn, "SELECT * FROM orders ORDER BY order_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Orders - Sales Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #fff0f5;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffb6c1;
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
            color: #fff;
        }

        .text-white {
            font-weight: 500;
        }

        h3 {
            color: #cc3366;
        }

        .btn-secondary {
            background-color: #ffc0cb;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #ff8fb2;
        }

        .card {
            border-radius: 16px;
            box-shadow: 0 0 10px rgba(255, 182, 193, 0.4);
        }

        .card-header {
            background-color: #ffb6c1;
            color: white;
            font-weight: 600;
        }

        .table thead {
            background-color: #ffe4e1;
        }

        .table th, .table td {
            vertical-align: middle;
        }

        .form-select-sm {
            border-radius: 10px;
        }

        .btn-success {
            background-color: #ffb6c1;
            border: none;
            color: #fff;
        }

        .btn-success:hover {
            background-color: #faa307;
        }

        .btn-outline-light {
            color: #fff;
            border-color: #fff;
        }

        .btn-outline-light:hover {
            background-color: #fff;
            color: #ff69b4 !important;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark px-4">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Manage Customer Orders</a>
        <div class="ms-auto">
            <span class="text-white">Welcome, <?php echo $_SESSION['user']; ?> (Sales)</span>
            <a href="logout.php" class="btn btn-outline-light ms-3">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    

   

    <!-- Orders Table -->
    <div class="card">
        <div class="card-header">Customer Orders List</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped shadow-sm">
                    <thead>
                        <tr>
                            <th>#ID</th>
                            <th>Customer</th>
                            <th>Total Amount</th>
                            <th>Delivery Address</th>
                            <th>Order Date</th>
                            <th>Payment Method</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($orders)) { ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                                <td>₹<?php echo $row['total_amount']; ?></td>
                                <td><?php echo htmlspecialchars($row['delivery_address']); ?></td>
                                <td><?php echo $row['order_date']; ?></td>
                                <td><?php echo $row['payment_method']; ?></td>
                                <td><?php echo $row['status']; ?></td>
                                <td>
                                    <form method="POST" class="d-flex gap-2">
                                        <input type="hidden" name="order_id" value="<?php echo $row['id']; ?>">
                                        <select name="status" class="form-select form-select-sm">
                                            <option value="Pending" <?php if ($row['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                                            <option value="Delivered" <?php if ($row['status'] == 'Delivered') echo 'selected'; ?>>Delivered</option>
                                            <option value="Cancelled" <?php if ($row['status'] == 'Cancelled') echo 'selected'; ?>>Cancelled</option>
                                        </select>
                                        <button type="submit" name="update_order" class="btn btn-sm btn-success">Update</button>
                                    </form>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <br>
    <a href="sales_dashboard.php" class="btn btn-secondary mb-3">← Back to Dashboard</a>
</div>

</body>
</html>

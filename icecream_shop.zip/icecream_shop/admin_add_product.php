<?php
session_start();
include('config/db.php');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_name = $_POST['product_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $available_units = $_POST['available_units'];

    // Handle image upload
    $image_name = $_FILES['product_image']['name'];
    $image_tmp = $_FILES['product_image']['tmp_name'];
    $unique_name = time() . '_' . basename($image_name);
    $upload_dir = 'uploads/';
    $image_path = $upload_dir . $unique_name;

    // Ensure upload directory exists
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    if (move_uploaded_file($image_tmp, $image_path)) {
        $stmt = $conn->prepare("INSERT INTO inventory (product_name, description, price, available_units, image_path, last_updated) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssdis", $product_name, $description, $price, $available_units, $unique_name);

        if ($stmt->execute()) {
            $success = "🍨 Product added successfully!";
        } else {
            $error = "❌ Database error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $error = "⚠️ Error uploading image.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Product - Ice Cream Co.</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff0f5;
            font-family: 'Quicksand', sans-serif;
        }

        h2 {
            font-family: 'Pacifico', cursive;
            color: #ff69b4;
        }

        .card {
            border-radius: 20px;
            box-shadow: 0 4px 12px rgba(255, 182, 193, 0.3);
            background-color: #fffafc;
        }

        .form-label {
            color: #d63384;
            font-weight: 600;
        }

        .btn-primary {
            background-color: #ff85a2;
            border: none;
        }

        .btn-primary:hover {
            background-color: #ff6991;
        }

        .btn-secondary {
            background-color: #b5ead7;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #98dbc6;
        }

        .alert-success {
            background-color: #c1f0dc;
            color: #1a7a57;
        }

        .alert-danger {
            background-color: #ffe5ec;
            color: #b02a37;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">🍦 Add a New Ice Cream Product</h2>

    <?php if (!empty($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php elseif (!empty($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <form action="" method="POST" enctype="multipart/form-data" class="card p-4">
        <div class="mb-3">
            <label for="product_name" class="form-label">Product Name:</label>
            <input type="text" name="product_name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description:</label>
            <textarea name="description" class="form-control" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label for="price" class="form-label">Price (₹):</label>
            <input type="number" name="price" class="form-control" required step="0.01">
        </div>
        <div class="mb-3">
            <label for="available_units" class="form-label">Available Units:</label>
            <input type="number" name="available_units" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="product_image" class="form-label">Product Image:</label>
            <input type="file" name="product_image" class="form-control" accept="image/*" required>
        </div>
        <button type="submit" class="btn btn-primary">➕ Add Product</button>
        <a href="admin_inventory.php" class="btn btn-secondary">📦 View Inventory</a>
    </form>
</div>
</body>
</html>

<?php
include('config/db.php');

if (!isset($_GET['id'])) {
    echo "No invoice ID provided.";
    exit();
}

$order_id = intval($_GET['id']);

// Fetch order
$order_query = "SELECT * FROM orders WHERE id = $order_id";
$order_result = mysqli_query($conn, $order_query);

if (!$order_result || mysqli_num_rows($order_result) == 0) {
    echo "Invoice not found.";
    exit();
}

$order = mysqli_fetch_assoc($order_result);

// Fetch order items with product names
$items_query = "SELECT oi.*, inv.product_name 
                FROM order_items oi 
                JOIN inventory inv ON oi.product_id = inv.id 
                WHERE oi.order_id = {$order['id']}";
$items_result = mysqli_query($conn, $items_query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Ice Cream Co. Invoice</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff0f5;
            font-family: 'Quicksand', sans-serif;
        }

        h2 {
            font-family: 'Pacifico', cursive;
            color: #d63384;
        }

        .invoice-box {
            background: #fff;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 0 15px rgba(255, 182, 193, 0.4);
            margin-top: 50px;
        }

        .table thead {
            background-color: #ffe4e1;
        }

        .btn-success {
            background-color: #fcbf49;
            border: none;
            font-weight: 600;
        }

        .btn-success:hover {
            background-color: #faa307;
        }

        .btn-secondary {
            background-color: #ffb6c1;
            border: none;
            font-weight: 600;
        }

        .btn-secondary:hover {
            background-color: #ff8fb2;
        }

        .table th, .table td {
            vertical-align: middle;
        }

        .text-end {
            text-align: right;
        }

        @media print {
            .btn {
                display: none !important;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="invoice-box">
        <h2 class="mb-4"> Ice Cream Co. Invoice</h2>

        <p><strong>Invoice #:</strong> #<?php echo $order['id']; ?></p>
        <p><strong>Date:</strong> <?php echo date("d M Y, h:i A", strtotime($order['order_date'])); ?></p>
        <p><strong>Customer:</strong> <?php echo htmlspecialchars($order['customer_name']); ?></p>
        <p><strong>Payment Method:</strong> <?php echo $order['payment_method']; ?></p>

        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>#</th>
                    <th> Product</th>
                    <th>Quantity</th>
                    <th>Price (₹)</th>
                    <th>Total (₹)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $grand_total = 0;
                $i = 1;
                while ($item = mysqli_fetch_assoc($items_result)):
                    $total = $item['price'] * $item['quantity'];
                    $grand_total += $total;
                ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                        <td><?php echo $item['quantity']; ?></td>
                        <td><?php echo number_format($item['price'], 2); ?></td>
                        <td><?php echo number_format($total, 2); ?></td>
                    </tr>
                <?php endwhile; ?>
                <tr>
                    <td colspan="4" class="text-end"><strong>Grand Total:</strong></td>
                    <td><strong>₹<?php echo number_format($grand_total, 2); ?></strong></td>
                </tr>
            </tbody>
        </table>

        <div class="text-center mt-4">
            <button class="btn btn-success" onclick="window.print()">🖨️ Print Invoice</button>
            <a href="sales_invoice.php" class="btn btn-secondary">← Back</a>
        </div>
    </div>
</div>
</body>
</html>

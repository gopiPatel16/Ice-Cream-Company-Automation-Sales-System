<?php
session_start();
include('config/db.php');

// Redirect if not admin
if (!isset($_SESSION['user']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: admin_inventory.php");
    exit();
}

$id = $_GET['id'];
$product = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM inventory WHERE id = $id"));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['product_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $units = $_POST['available_units'];

    // Image handling
    if (!empty($_FILES['image']['name'])) {
        $image_name = time() . '_' . basename($_FILES['image']['name']);
        $target = "uploads/" . $image_name;
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
    } else {
        $image_name = $product['image_path'];
    }

    $stmt = $conn->prepare("UPDATE inventory SET product_name=?, description=?, price=?, available_units=?, image_path=?, last_updated=NOW() WHERE id=?");
    $stmt->bind_param("ssdisi", $name, $description, $price, $units, $image_name, $id);

    if ($stmt->execute()) {
        header("Location: admin_inventory.php?updated=true");
        exit();
    } else {
        $error = "Update failed.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h3 class="text-center mb-4">Edit Product</h3>
    <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
    <form method="post" enctype="multipart/form-data" class="card p-4 shadow-sm bg-white">
        <div class="mb-3">
            <label class="form-label">Product Name</label>
            <input type="text" name="product_name" class="form-control" value="<?php echo $product['product_name']; ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" required><?php echo $product['description']; ?></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Price (₹)</label>
            <input type="number" step="0.01" name="price" class="form-control" value="<?php echo $product['price']; ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Available Units</label>
            <input type="number" name="available_units" class="form-control" value="<?php echo $product['available_units']; ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Product Image</label><br>
            <img src="uploads/<?php echo $product['image_path']; ?>" height="100" class="mb-2"><br>
            <input type="file" name="image" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Update Product</button>
        <a href="admin_inventory.php" class="btn btn-secondary ms-2">Back</a>
    </form>
</div>

</body>
</html>
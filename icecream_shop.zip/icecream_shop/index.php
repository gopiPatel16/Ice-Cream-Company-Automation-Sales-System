<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ice Cream Manufacturing Company</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Basic CSS -->
  <style>
    body {
      background: url('icecream-bg.jpg') no-repeat center center fixed;
      background-size: cover;
      font-family: Arial, sans-serif;
      color: #333;
      margin: 0;
      padding: 0;
    }
    .overlay {
      background-color: rgba(255, 255, 255, 0.85);
      min-height: 100vh;
    }
    .navbar {
      background-color: #ffc0cb;
    }
    .navbar-brand {
      font-size: 1.8rem;
      color: #fff !important;
    }
    .nav-link {
      color: #fff !important;
    }
    .nav-link:hover {
      color: #6c2c3f !important;
    }
    .intro-section {
      padding: 80px 20px;
      text-align: center;
    }
    .intro-section h1 {
      font-size: 2.5rem;
      color: #d6336c;
    }
    .intro-section p {
      font-size: 1rem;
      color: #444;
      max-width: 700px;
      margin: 0 auto 20px;
    }
    .btn-custom {
      background-color: #e75480;
      color: white;
      border-radius: 20px;
      padding: 10px 20px;
      font-weight: bold;
      border: none;
    }
    .btn-custom:hover {
      background-color: #c92457;
    }
    .contact-section {
      background-color: #fff0f5;
      padding: 50px 10px;
      border-top: 4px dashed #ffa6c9;
    }
    .contact-section h2 {
      color: #d6336c;
      margin-bottom: 30px;
    }
    .contact-section h5 {
      color: #a52a2a;
    }
    .footer {
      background-color: #ffb6c1;
      color: white;
      text-align: center;
      padding: 10px 0;
      font-size: 14px;
      margin-top: 40px;
    }
  </style>
</head>
<body>
  <div class="overlay">

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <a class="navbar-brand" href="#">Ice Cream Co.</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link active" href="login.php">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="signup.php">Sign Up</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Intro Section -->
    <section class="intro-section">
      <div class="container">
        <h1>Welcome to Ice Cream Co.</h1>
        <p>Delighting taste buds with the creamiest, freshest, and most delightful ice creams!<br>
        Manage your orders, track sales, and keep your inventory in check with our automation system.</p>

        <a href="login.php" class="btn btn-custom">Get Started</a>
      </div>
    </section>

    <!-- Contact Section -->
    <section class="contact-section">
      <div class="container text-center">
        <h2>Contact Us</h2>
        <div class="row">
          <div class="col-md-4 mb-3">
            <h5> Address</h5>
            <p>Udupi Web Solutions, 1st Floor, AVA Complex,<br>Beside Karnataka Bank, Kunjibettu, Udupi</p>
          </div>
          <div class="col-md-4 mb-3">
            <h5>Email</h5>
            <p>info@icecreamco.com</p>
          </div>
          <div class="col-md-4 mb-3">
            <h5>Phone</h5>
            <p>+91 9876543210</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
      <p>&copy; 2025 Ice Cream Co. All Rights Reserved.</p>
    </footer>

  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
session_start();
include('config/db.php');

// Redirect if not logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

// We'll treat $_SESSION['user'] as the user's name or email
$identifier = $_SESSION['user'];

// Get user details based on either name or email (adjust if needed)
$query = "SELECT * FROM users WHERE name = ? OR email = ? LIMIT 1";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $identifier, $identifier);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "User not found!";
    exit();
}

// Handle form submission for profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $updated_name = trim($_POST['name']);
    $updated_email = trim($_POST['email']);
    $updated_password = trim($_POST['password']);

    if (!empty($updated_password)) {
        $hashed_password = password_hash($updated_password, PASSWORD_DEFAULT);
        $update = $conn->prepare("UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?");
        $update->bind_param("sssi", $updated_name, $updated_email, $hashed_password, $user['id']);
    } else {
        $update = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
        $update->bind_param("ssi", $updated_name, $updated_email, $user['id']);
    }

    if ($update->execute()) {
        $success = "Profile updated successfully!";
        $_SESSION['user'] = $updated_name; // update session
        // Refresh the page to show updated info
        header("Location: customer_account_settings.php");
        exit();
    } else {
        $error = "Failed to update profile.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Account Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fff7f9;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: #ffb6c1 !important;
        }

        .navbar-brand {
            font-family: Arial, sans-serif;
            font-size: 1.8rem;
            color: #fff !important;
        }

        .navbar .nav-link,
        .navbar span {
            color: white !important;
            font-weight: 600;
        }

        .card {
            border-radius: 15px;
            background-color: #fff;
            border: none;
            transition: 0.3s ease-in-out;
        }

        .card:hover {
            transform: scale(1.03);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #ffa6b7;
            color: #fff;
            border-radius: 15px 15px 0 0;
            font-weight: 600;
            font-size: 1.2rem;
        }

        .btn {
            border-radius: 2rem;
            padding: 8px 25px;
            font-weight: 600;
        }

        .btn-primary {
            background-color: #ffb6c1;
            border: none;
        }

        .btn-primary:hover {
            background-color: #ff3366;
        }

        .btn-secondary {
            background-color: #ffb6c1;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #72aad7;
        }

        h2 {
            color: #ff4d6d;
            font-family: Arial, sans-serif;
        }

        .alert {
            font-weight: bold;
            text-align: center;
        }

        .form-control {
            border-radius: 1.5rem;
        }

        .form-label {
            font-weight: 600;
        }

        
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#"> Account Settings.</a>
        <div class="ms-auto text-white">
            Welcome, <?php echo $_SESSION['user']; ?> (Customer)
            <a href="logout.php" class="btn btn-outline-light ms-3">Logout</a>
        </div>
    </div>
</nav>

<div class="container mt-5">

    <h2 class="mb-4">Settings</h2>

    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php elseif (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="card mb-4 shadow">
            <div class="card-header">
                Update Your Profile
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label for="name" class="form-label">Name:</label>
                    <input type="text" name="name" class="form-control" required value="<?php echo htmlspecialchars($user['name']); ?>">
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" name="email" class="form-control" required value="<?php echo htmlspecialchars($user['email']); ?>">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">New Password (leave blank to keep current):</label>
                    <input type="password" name="password" class="form-control" placeholder="••••••••">
                </div>
                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-primary">Update Profile</button>
                    <a href="customer_dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
                </div>
            </div>
        </div>
    </form>
</div>

</body>
</html>
